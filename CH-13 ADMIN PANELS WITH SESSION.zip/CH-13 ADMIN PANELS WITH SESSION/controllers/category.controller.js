const Category = require('../model/category.model');
const SubCategory = require('../model/subcategory.model');
const ExtraCategory = require('../model/extracategory.model');
const Product = require('../model/product.model');
const fs = require('fs');

// Add Category Page
module.exports.addCategoryPage = async (req, res) => {
    try {
        return res.render('category/addCategory');
    } catch (err) {
        console.log("Add Category Page Error:", err);
        return res.redirect('/dashboard');
    }
};

// Insert Category
module.exports.insertCategory = async (req, res) => {
    try {
        req.body.category_image = req.file.path;
        await Category.create(req.body);
        req.flash('success', "Category Inserted Successfully..");
        return res.redirect('/category/addCategoryPage');
    } catch (err) {
        console.log("Insert Category Error:", err);
        req.flash('error', "Category Insertion Failed..");
        return res.redirect('/category/addCategoryPage');
    }
};

// View Category Page
module.exports.viewCategoryPage = async (req, res) => {
    try {
        const allCategory = await Category.find();
        return res.render('category/viewCategory', { allCategory });
    } catch (err) {
        console.log("View Category Error:", err);
        return res.redirect('/dashboard');
    }
};

// Delete Category
module.exports.deleteCategory = async (req, res) => {
    try {
        const categoryId = req.query.Id;

        // Delete all products and their images
        const products = await Product.find({ category_id: categoryId });
        for (const product of products) {
            if (product.image) {
                fs.unlink(product.image, () => { });
            }
        }
        await Product.deleteMany({ category_id: categoryId });

        // Delete all extra categories
        await ExtraCategory.deleteMany({ category_id: categoryId });

        // Delete all subcategories and their images
        const subcategories = await SubCategory.find({ category_id: categoryId });
        for (const subcategory of subcategories) {
            if (subcategory.subcategory_image) {
                fs.unlink(subcategory.subcategory_image, () => { });
            }
        }
        await SubCategory.deleteMany({ category_id: categoryId });

        // Delete the category itself
        const deleted = await Category.findByIdAndDelete(categoryId);

        if (deleted) {
            if (deleted.category_image) {
                fs.unlink(deleted.category_image, () => { });
            }
            req.flash('success', `${deleted.category_name} and all related items Deleted Successfully..`);
        }
        else {
            req.flash('error', "Failed to Delete Category..");
        }

        return res.redirect('/category/viewCategoryPage');
    } catch (err) {
        console.log("Delete Category Error:", err);
        req.flash('error', "Category Deletion Failed..");
        return res.redirect('/category/viewCategoryPage');
    }
};

// Edit Category Page
module.exports.editCategoryPage = async (req, res) => {
    try {
        const category = await Category.findById(req.params.categoryId);
        if (!category) {
            req.flash('error', "Category Not Found..");
            return res.redirect('/category/viewCategoryPage');
        }
        return res.render('category/editCategory', { category });
    } catch (err) {
        console.log("Edit Category Page Error:", err);
        return res.redirect('/category/viewCategoryPage');
    }
};

// Update Category
module.exports.updateCategory = async (req, res) => {
    try {
        const category = await Category.findById(req.params.categoryId);
        if (!category) {
            req.flash('error', "Category Not Found..");
            return res.redirect('/category/viewCategoryPage');
        }

        if (req.file) {
            req.body.category_image = req.file.path;
            if (category.category_image) {
                fs.unlink(category.category_image, () => { });
            }
        }

        await Category.findByIdAndUpdate(req.params.categoryId, req.body);
        req.flash('success', "Category Updated Successfully..");
        return res.redirect('/category/viewCategoryPage');
    } catch (err) {
        console.log("Update Category Error:", err);
        req.flash('error', "Category Update Failed..");
        return res.redirect('/category/viewCategoryPage');
    }
};